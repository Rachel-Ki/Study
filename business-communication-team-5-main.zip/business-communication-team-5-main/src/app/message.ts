export interface Message {
    username: string; 
    avatarURL: string;
    chatMessage: string;
    timeStamp: any;
    edited: boolean;
}